// Register ScrollTrigger with GSAP
gsap.registerPlugin(ScrollTrigger);

/* ==========================================
   1. CUSTOM CURSOR
   ========================================== */
const cursor = document.querySelector('.custom-cursor');
let mouseX = 0, mouseY = 0;
let cursorX = 0, cursorY = 0;

document.addEventListener('mousemove', (e) => {
  mouseX = e.clientX;
  mouseY = e.clientY;
});

// Smooth cursor interpolation
gsap.ticker.add(() => {
  const dt = 1.0 - Math.pow(0.1, gsap.ticker.deltaRatio() * 0.05);
  cursorX += (mouseX - cursorX) * dt;
  cursorY += (mouseY - cursorY) * dt;
  
  if (cursor) {
    cursor.style.left = `${cursorX}px`;
    cursor.style.top = `${cursorY}px`;
  }
});

// Cursor hover function
function initCursorHover() {
  const hoverElements = document.querySelectorAll('a, button, select, input, .nav-btn, .hotspot-trigger, option, .size-chip');
  hoverElements.forEach(el => {
    // Avoid double bindings
    el.removeEventListener('mouseenter', addCursorHover);
    el.removeEventListener('mouseleave', removeCursorHover);
    el.addEventListener('mouseenter', addCursorHover);
    el.addEventListener('mouseleave', removeCursorHover);
  });
}

function addCursorHover() { cursor.classList.add('hovered'); }
function removeCursorHover() { cursor.classList.remove('hovered'); }

initCursorHover();

/* ==========================================
   2. LENIS SMOOTH SCROLL
   ========================================== */
const lenis = new Lenis({
  duration: 1.4,
  easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
  direction: 'vertical',
  gestureDirection: 'vertical',
  smooth: true,
  mouseMultiplier: 1,
  smoothTouch: false,
  touchMultiplier: 2,
  infinite: false,
});

// Bind Lenis scroll to ScrollTrigger
lenis.on('scroll', ScrollTrigger.update);

gsap.ticker.add((time) => {
  lenis.raf(time * 1000);
});

gsap.ticker.lagSmoothing(0);

/* ==========================================
   3. HERO ENTRANCE ANIMATION
   ========================================== */
const heroTl = gsap.timeline({ defaults: { ease: 'power4.out' } });

heroTl.from('.header', {
  yPercent: -100,
  opacity: 0,
  duration: 1.2,
})
.from('.hero-title', {
  y: 60,
  opacity: 0,
  duration: 1.2,
}, '-=0.8')
.from('.hero-subtitle', {
  letterSpacing: '20px',
  opacity: 0,
  duration: 1.2,
}, '-=1.0')
.from('.hero-desc', {
  y: 30,
  opacity: 0,
  duration: 1.0,
}, '-=0.9')
.from('.hero-image', {
  scale: 0.8,
  opacity: 0,
  y: 50,
  duration: 1.5,
  ease: 'elastic.out(1, 0.75)'
}, '-=0.8')
.from('.scroll-indicator', {
  opacity: 0,
  y: 20,
  duration: 1.0,
}, '-=0.5');

// Floating animation for Hero image
gsap.to('.hero-image', {
  y: -15,
  duration: 3,
  ease: 'sine.inOut',
  repeat: -1,
  yoyo: true
});

/* ==========================================
   4. SCROLLTRIGGER: HERO TO DETAILS TRANSITION
   ========================================== */
const transitionTl = gsap.timeline({
  scrollTrigger: {
    trigger: '#hero',
    start: 'top top',
    end: 'bottom top',
    scrub: true,
  }
});

transitionTl.to('.hero-image', {
  xPercent: -50,
  scale: 0.75,
  opacity: 0,
  filter: 'blur(10px)',
  ease: 'none'
}, 0);

/* Pinned details section reveal effect */
const detailsBlocks = document.querySelectorAll('.details-content-block');
detailsBlocks.forEach((block, index) => {
  ScrollTrigger.create({
    trigger: block,
    start: 'top 75%',
    end: 'bottom 40%',
    onEnter: () => {
      block.classList.add('active');
      gsap.to('.sticky-product-img', {
        rotation: (index - 1) * 6,
        scale: 1.0 + (index * 0.05),
        duration: 0.8,
        ease: 'power2.out'
      });
    },
    onLeaveBack: () => {
      block.classList.remove('active');
      gsap.to('.sticky-product-img', {
        rotation: (index - 1) * 3,
        scale: 0.95 + (index * 0.03),
        duration: 0.8,
        ease: 'power2.out'
      });
    }
  });
});

/* ==========================================
   5. FEATURE TRANSITIONS & HOTSPOTS
   ========================================== */
const featuresTl = gsap.timeline({
  scrollTrigger: {
    trigger: '#features',
    start: 'top 85%',
    end: 'top 20%',
    scrub: true,
  }
});

featuresTl.to('.sticky-product-img', {
  opacity: 0,
  scale: 0.8,
  duration: 1,
}, 0)
.from('.interactive-layout-wrapper', {
  opacity: 0,
  y: 60,
  duration: 1.5,
}, 0);

gsap.from('.hotspot', {
  scale: 0,
  opacity: 0,
  stagger: 0.15,
  duration: 0.8,
  ease: 'back.out(1.7)',
  scrollTrigger: {
    trigger: '#features',
    start: 'top 50%',
  }
});


/* ==========================================
   7. SHOPPING CART & STATE MANAGEMENT
   ========================================== */
const PRODUCT_PRICE = 350;
const PRODUCT_NAME = "Signature Peach Polo";

let cart = JSON.parse(localStorage.getItem('ekadant_cart')) || [];

// DOM Elements
const cartToggleBtn = document.querySelector('.cart-toggle-btn');
const closeCartBtn = document.querySelector('.close-cart-btn');
const cartDrawer = document.querySelector('.cart-drawer');
const cartOverlay = document.querySelector('.cart-drawer-overlay');
const cartBadge = document.querySelector('.cart-badge');
const cartEmptyMsg = document.querySelector('.cart-empty-message');
const cartItemsList = document.querySelector('.cart-items-list');
const cartSubtotalVal = document.querySelector('.cart-subtotal-val');
const addToCartForm = document.getElementById('add-to-cart-form');
const checkoutBtn = document.querySelector('.checkout-btn');

// Update UI badges and items
function updateCartUI() {
  localStorage.setItem('ekadant_cart', JSON.stringify(cart));
  
  // Update badge count
  const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  cartBadge.innerText = totalCount;
  
  // Animate badge change
  cartBadge.classList.remove('pop');
  void cartBadge.offsetWidth; // Trigger reflow
  cartBadge.classList.add('pop');

  if (cart.length === 0) {
    cartEmptyMsg.style.display = 'flex';
    cartItemsList.style.display = 'none';
    checkoutBtn.disabled = true;
    checkoutBtn.style.opacity = '0.5';
    checkoutBtn.style.pointerEvents = 'none';
    cartSubtotalVal.innerText = '₹0.00';
  } else {
    cartEmptyMsg.style.display = 'none';
    cartItemsList.style.display = 'flex';
    checkoutBtn.disabled = false;
    checkoutBtn.style.opacity = '1';
    checkoutBtn.style.pointerEvents = 'auto';
    
    // Render list
    cartItemsList.innerHTML = '';
    let subtotal = 0;
    
    cart.forEach((item, index) => {
      const itemTotal = PRODUCT_PRICE * item.quantity;
      subtotal += itemTotal;
      
      const itemEl = document.createElement('div');
      itemEl.className = 'cart-item';
      itemEl.innerHTML = `
        <img src="assets/silk_showcase.jpg" alt="Vikhrolicha Ekadant Polo" class="cart-item-img">
        <div class="cart-item-info">
          <h4>${PRODUCT_NAME}</h4>
          <div class="cart-item-meta">Size: ${item.size}</div>
          <div class="cart-item-qty">
            <button type="button" class="qty-btn" onclick="changeCartQty(${index}, -1)">−</button>
            <span class="qty-value">${item.quantity}</span>
            <button type="button" class="qty-btn" onclick="changeCartQty(${index}, 1)">+</button>
          </div>
        </div>
        <div class="cart-item-right">
          <button type="button" class="cart-item-remove" onclick="removeCartItem(${index})" aria-label="Remove item">×</button>
          <span class="cart-item-price">₹${itemTotal.toLocaleString('en-IN')}.00</span>
        </div>
      `;
      cartItemsList.appendChild(itemEl);
    });
    
    cartSubtotalVal.innerText = `₹${subtotal.toLocaleString('en-IN')}.00`;
  }
  
  // Re-initialize custom cursor hover events for newly created buttons
  initCursorHover();
}

// Global functions for inline onclick handlers
window.changeCartQty = function(index, delta) {
  cart[index].quantity += delta;
  if (cart[index].quantity <= 0) {
    cart.splice(index, 1);
  }
  updateCartUI();
};

window.removeCartItem = function(index) {
  cart.splice(index, 1);
  updateCartUI();
};

// Add item to cart
function addToCart(size, quantity) {
  const existingIdx = cart.findIndex(item => item.size === size);
  
  if (existingIdx > -1) {
    cart[existingIdx].quantity += quantity;
  } else {
    cart.push({
      name: PRODUCT_NAME,
      size: size,
      quantity: quantity,
      price: PRODUCT_PRICE
    });
  }
  
  updateCartUI();
  
  // Auto open cart
  openCart();
}

// Open/Close Cart
function openCart() {
  cartDrawer.classList.add('active');
  cartOverlay.classList.add('active');
}

function closeCart() {
  cartDrawer.classList.remove('active');
  cartOverlay.classList.remove('active');
}

// Event Bindings
cartToggleBtn.addEventListener('click', openCart);
closeCartBtn.addEventListener('click', closeCart);
cartOverlay.addEventListener('click', closeCart);

// Buy Now button scrolling to form
const buyBtn = document.querySelector('.nav-btn');
buyBtn.addEventListener('click', (e) => {
  e.preventDefault();
  lenis.scrollTo('#order');
});

// Quantity Counter handlers on purchase page
const buyQtyCounter = document.querySelector('.qty-counter');
const buyQtyVal = buyQtyCounter.querySelector('.qty-value');
const buyDecBtn = buyQtyCounter.querySelector('.dec-btn');
const buyIncBtn = buyQtyCounter.querySelector('.inc-btn');
let selectedQty = 1;

buyIncBtn.addEventListener('click', () => {
  selectedQty++;
  buyQtyVal.innerText = selectedQty;
});

buyDecBtn.addEventListener('click', () => {
  if (selectedQty > 1) {
    selectedQty--;
    buyQtyVal.innerText = selectedQty;
  }
});

// Add to Cart Form Submission
addToCartForm.addEventListener('submit', (e) => {
  e.preventDefault();
  
  const sizeOption = document.querySelector('input[name="size"]:checked');
  if (!sizeOption) {
    alert("Please select a size first!");
    return;
  }
  
  const size = sizeOption.value;
  addToCart(size, selectedQty);
  
  // Reset form selected quantity
  selectedQty = 1;
  buyQtyVal.innerText = 1;
});

// Initialize UI
updateCartUI();


/* ==========================================
   8. CHECKOUT WIZARD MODAL
   ========================================== */
const checkoutOverlay = document.querySelector('.checkout-modal-overlay');
const closeCheckoutBtn = document.querySelector('.close-checkout-btn');
const shippingForm = document.getElementById('shipping-form');
const paymentForm = document.getElementById('payment-form');
const orderIdPlaceholder = document.getElementById('order-id-placeholder');
const continueShoppingBtn = document.querySelector('.continue-shopping-btn');

// Progress Steps
const progShipping = document.getElementById('prog-shipping');
const progPayment = document.getElementById('prog-payment');
const progComplete = document.getElementById('prog-complete');

// Content Sections
const stepShipping = document.getElementById('step-shipping');
const stepPayment = document.getElementById('step-payment');
const stepComplete = document.getElementById('step-complete');

const summaryItems = document.querySelector('.summary-items');
const summaryTotalVal = document.querySelector('.summary-total-val');
const paymentBackBtn = document.querySelector('.back-btn');

function openCheckout() {
  closeCart();
  
  // Reset checkout state
  goStepShipping();
  
  checkoutOverlay.classList.add('active');
}

function closeCheckout() {
  checkoutOverlay.classList.remove('active');
}

function goStepShipping() {
  progShipping.className = 'progress-step active';
  progPayment.className = 'progress-step';
  progComplete.className = 'progress-step';
  
  progShipping.nextElementSibling.classList.remove('filled');
  progPayment.nextElementSibling.classList.remove('filled');
  
  stepShipping.classList.add('active');
  stepPayment.classList.remove('active');
  stepComplete.classList.remove('active');
}

function goStepPayment() {
  progShipping.className = 'progress-step complete';
  progPayment.className = 'progress-step active';
  progComplete.className = 'progress-step';
  
  progShipping.nextElementSibling.classList.add('filled');
  progPayment.nextElementSibling.classList.remove('filled');
  
  stepShipping.classList.remove('active');
  stepPayment.classList.add('active');
  stepComplete.classList.remove('active');
  
  // Populate summary boxes
  summaryItems.innerHTML = '';
  let subtotal = 0;
  
  cart.forEach(item => {
    const itemTotal = PRODUCT_PRICE * item.quantity;
    subtotal += itemTotal;
    
    const row = document.createElement('div');
    row.className = 'summary-item-row';
    row.innerHTML = `
      <span>${PRODUCT_NAME} (Size: ${item.size}) x${item.quantity}</span>
      <span>₹${itemTotal.toLocaleString('en-IN')}.00</span>
    `;
    summaryItems.appendChild(row);
  });
  
  summaryTotalVal.innerText = `₹${subtotal.toLocaleString('en-IN')}.00`;
}

function goStepComplete() {
  progShipping.className = 'progress-step complete';
  progPayment.className = 'progress-step complete';
  progComplete.className = 'progress-step active';
  
  progShipping.nextElementSibling.classList.add('filled');
  progPayment.nextElementSibling.classList.add('filled');
  
  stepShipping.classList.remove('active');
  stepPayment.classList.remove('active');
  stepComplete.classList.add('active');
  
  // Generate random order ID
  const orderId = 'EKD-' + Math.floor(100000 + Math.random() * 900000);
  orderIdPlaceholder.innerText = orderId;
  
  // Clear Cart
  cart = [];
  updateCartUI();
}

checkoutBtn.addEventListener('click', openCheckout);
closeCheckoutBtn.addEventListener('click', closeCheckout);

shippingForm.addEventListener('submit', (e) => {
  e.preventDefault();
  goStepPayment();
});

paymentBackBtn.addEventListener('click', goStepShipping);

paymentForm.addEventListener('submit', (e) => {
  e.preventDefault();
  goStepComplete();
});

continueShoppingBtn.addEventListener('click', () => {
  closeCheckout();
  lenis.scrollTo('#hero');
});
